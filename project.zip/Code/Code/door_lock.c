#include<reg51.h>
#include<string.h>
sbit RS = P3^0;
sbit EN = P3^1;
sbit IN1 =P3^2;
sbit IN2 = P3^3;

// time delay
void delay(int a)
{
	unsigned int i,j;
	for(i=0;i<a;i++)
		for(j=0;j<255;j++);
}

// command in lcd
void cmd(char cm)
{
	P2 = cm;
	RS = 0;
	EN = 1;
	delay(1);
	EN = 0;
}

// reset by calling first location of ROM
void reset(void)
{
	((void (code *) (void)) 0x0000) ();
}

// display single charecter in lcd
void dat(char dt)
{
	P2 = dt;
	RS = 1;
	EN = 1;
	delay(1);
	EN = 0;
}

// display a string in lcd
void display(char *lcd)
{
	while(*lcd != '\0')
	{
		dat(*lcd);
		lcd++;
	}
}

// initialize lcd
void lcdint()
{
	cmd(0x01);
	cmd(0x38);
	cmd(0x0E);
	cmd(0x80);
}


void main()
{
	char pass[5] = "1234";
	char pass2[5];
	int i=0;
	lcdint();
	display("Enter Password..");
	pass2[4]='\0';
	cmd(0xC0);
	
	while(1)
	{
		while(i<4)
		{
			P1=0x7E;
			if(P1==0x6E)
			{
				pass2[i]='1';
				dat('*');
				delay(200);
				cmd(0x06);
				i++;
			}
			else if(P1==0x5E)
			{
				pass2[i]='2';
				dat('*');
				delay(200);
				cmd(0x06);
				i++;
			}
			else if(P1==0x3E)
			{
				pass2[i]='3';
				dat('*');
				delay(200);
				cmd(0x06);
				i++;
			}		
	
			P1=0x7D;
			if(P1==0x6D)
			{
				pass2[i]='4';
				dat('*');
				delay(200);
				cmd(0x06);
				i++;
			}
			else if(P1==0x5D)
			{
				pass2[i]='5';
				dat('*');
				delay(200);
				cmd(0x06);
				i++;
			}
			else if(P1==0x3D)
			{
				pass2[i]='6';
				dat('*');
				delay(200);
				cmd(0x06);
				i++;
			}	
	
			P1=0x7B;
			if(P1==0x6B)
			{
				pass2[i]='7';
				dat('*');
				delay(200);
				cmd(0x06);
				i++;
			}
			else if(P1==0x5B)
			{
				pass2[i]='8';
				dat('*');
				delay(200);
				cmd(0x06);
				i++;
			}
			else if(P1==0x3B)
			{
				pass2[i]='9';
				dat('*');
				delay(200);
				cmd(0x06);
				i++;
			}
	
			P1=0x77;
			if(P1==0x67)
			{
				pass2[i]='*';
				dat('*');
				delay(200);
				cmd(0x06);
				i++;
			}
			else if(P1==0x57)
			{
				pass2[i]='0';
				dat('*');
				delay(200);
				cmd(0x06);
				i++;
			}
			else if(P1==0x37)
			{
				pass2[i]='#';
				dat('*');
				delay(200);
				cmd(0x06);
				i++;
			}
		}

		if(i==4)
		{

			if ((strcmp(pass, pass2)) == 0)
			{
				cmd(0xC0);
				display("Correct");
				delay(200);
				cmd(0x01);
				cmd(0x80);
				display("Opening...");
				IN1 = 1;
				IN2 = 0;
				delay(255);
				IN1=0;
				IN2=0;
				cmd(0x01);
				cmd(0x80);
				display("     Opened     ");
				delay(200);
				IN1=0;
				IN2=1;
				cmd(0x01);
				cmd(0x80);
				display("    Closing    ");
				delay(255);
				IN1=0;
				IN2=0;
				reset();				
					
			}
			else
			{
				cmd(0xC0);
				display("Incorrect");
				IN1 = 0;
				IN2 = 0;
				delay(200);
				cmd(0x01);
				display("Try Again");
				delay(200);
				reset();
			}
		}
	}
}